RUNMODES = ["once", "forever", "async"]

RUNMODE = "once"

NWORKERS = 4

