spydy
===============================

version number: 0.1.0
author: Jiang Chaodi

Overview
--------

A python package that can be installed with pip.

Installation / Usage
--------------------

To install use pip:

    $ pip install spydy


Or clone the repo:

    $ git clone https://github.com/superjcd/spydy.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD